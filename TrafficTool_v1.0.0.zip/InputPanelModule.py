import tkinter as tk
import tkinter as tk
from tkinter import Tk, ttk, filedialog, messagebox
from PIL import Image, ImageTk

import cv2
import pandas as pd
import re
import os

from datetime import date, datetime, time, timedelta


# timers for efficiency testing
from functools import wraps
import time
def timeit(func):
    @wraps(func)
    def timeit_wrapper(*args, **kwargs):
        start_time = time.perf_counter()
        result = func(*args, **kwargs)
        end_time = time.perf_counter()
        total_time = end_time - start_time
        print(f'Function {func.__name__}{args} {kwargs} took {total_time:.4f} seconds')
        return result
    return timeit_wrapper

class InputPanel(tk.Frame):
    def __init__(self, file_path=None, num_lanes=6, max_length=10, parent=None, debug=False):
        super().__init__()
        self.file_path = file_path
        self.num_lanes = num_lanes
        self.max_length = max_length
        self.parent = parent
        self.debug = debug
        
        parent.rowconfigure(0,weight=1)
        parent.columnconfigure(0,weight=1)
        
        self.header = ["Time"] + ["L" + str(i + 1) for i in range(num_lanes)]
        self.time = datetime.now() # individual testing purposes
        
        self.result_file = None
        self.index_func = None
        self.file_path_func = None
        self.next_func = None
        
        if (file_path != None):
            self.load(self.file_path)
        
        self.curr_status = [-1] * num_lanes
        
        self.createTkPanel()
        
    def load(self, file_path=None, show=False):
        self.file_path = self.file_path if file_path == None else file_path
        
#         file_name = re.search("\\\([^ \\/\"\',]+)\.mp4", self.file_path)[1] # parse out filename from filepath
        file_name = os.path.basename(self.file_path).split(".")[0]
        self.result_file = os.path.join('resultsTest', file_name) + '.xlsx' # construct result file name
        self.debug_print("result_file:" + str(self.result_file))

        # check if result file exists
        if os.path.exists(self.result_file) == False:
            self.df = pd.DataFrame(columns=self.header)
        else:
            self.df = pd.read_excel(self.result_file)
        
        self.df.set_index("Time", inplace=True)
        
    def inputLaneStatus(self, lane, length):
        if self.curr_status[lane] == length:
            self.button_list[length][lane].config(relief="raised", font="sans 10", bg="white")
            self.curr_status[lane] = -1
            return
            
        self.curr_status[lane] = length
        
        self.debug_print((length, lane))
        self.debug_print(self.curr_status)
        
        sel_btn = self.button_list[length][lane]
        sel_btn.config(relief="sunken", font='sans 10 bold', bg="yellow")

        for l in range(self.max_length):
            if l != length:
                self.button_list[l][lane].config(relief="raised", font='sans 10', bg="white")

    def enterEntry(self):
        if self.result_file == None:
            self.debug_print("entered entry but no result file selected")
            return self.resetInput()
        
        if self.file_path_func == None:
            self.debug_print("entered entry but no file path selected")
            messagebox.showinfo("Require Video", "needs video to enter into exel")
            return self.resetInput()
        
        self.result_file = self.file_path_func()
        
        time_index = self.getTimeIndex()
        if time_index == None:
            self.debug_print("time index function not bound")
            messagebox.showinfo("Require Video", "needs video to enter into exel")
            return self.resetInput()
        
        self.debug_print(time_index)
        
        self.debug_print("entered entry")
        self.df.loc[time_index] = self.curr_status
        self.debug_print("wrote into excel at " + self.result_file)
        self.df.to_excel(self.result_file)
        
        if self.next_func != None:
            self.next_func()
            self.debug_print("next")

        return self.resetInput()
    
    def resetInput(self):
        self.debug_print("reset input")
        self.curr_status = [-1] * self.num_lanes
        for l in range(self.max_length):
            for r in range(self.num_lanes):
                self.button_list[l][r].config(relief="raised", font='sans 10', bg="white")
                
    def getTimeIndex(self):
        if self.index_func != None:
            return self.index_func()
        
        return None
    
    def setNextFunc(self, func):
        self.next_func = func
    
    def setIndexFunc(self, func):
        self.index_func = func
        
    def setFilePathFunc(self, func):
        self.file_path_func = func

    def createTkPanel(self, num_lanes=None, max_length=None):
        self.num_lanes = self.num_lanes if num_lanes == None else num_lanes
        self.max_length = self.max_length if max_length == None else max_length
        
        self.button_list = []
        
        fill=tk.BOTH
        expand=True
        
        for i in range(self.num_lanes):
            frame = ttk.Frame(
                master=self.parent,
                borderwidth=1
            )
            frame.grid(row=0, column=i, sticky="nsew")
            
            header_label = tk.Label(master=frame, 
                     text=self.header[i + 1])
            header_label.pack(fill=fill, expand=expand)
            self.parent.rowconfigure(0, weight=0)
            
        for i in range(self.max_length):
            self.parent.rowconfigure(i + 1, weight=1) 
            
            self.button_list.append([])
            for j in range(self.num_lanes):
                self.parent.columnconfigure(j, weight=1) 
                
                frame = ttk.Frame(
                    master=self.parent,
                    relief="raised",
                    borderwidth=1,
                )
                frame.grid(row=(i + 1), column=(j), sticky="nsew")
                
                self.button_list[i].append(tk.Button(master=frame, 
                                                     text=f"{i}",
                                                     font='sans 10',
                                                     bg="white",
                                                     command=lambda j=j, i=i : self.inputLaneStatus(j, i)))
                self.button_list[i][j].pack(fill=fill, expand=expand)
        
        frame = ttk.Frame(
                    master=self.parent,
                    relief="raised",
                    borderwidth=1,
                )
        
        frame.grid(row=(self.max_length + 1), column=0, rowspan=4, columnspan=self.num_lanes, sticky="nsew")
        self.parent.rowconfigure((self.max_length + 1), weight=1) 

        self.entryButton = tk.Button(master=frame, 
                                     text=f"Enter Entry",
                                     font='sans 10',
                                     command=self.enterEntry)
        self.entryButton.pack(fill=fill, expand=expand)

    def debug_print(self, string):
        if self.debug: print(string)

def timeIndex():
    return "4200-04-20 04:20:00"

if __name__ == "__main__":
    root = Tk()
#     inpanel = InputPanel(file_path="vids\TLC00011.mp4", num_lanes=4, parent=root)
    input_panel = InputPanel(parent=root, debug=True)
    input_panel.setIndexFunc(timeIndex)
    input_panel.load(file_path="vids\\TLC00012.mp4")
    print("created object")
    root.mainloop()